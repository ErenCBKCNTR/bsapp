# Design System Document: The Luminescent Linear System

## 1. Overview & Creative North Star
**Creative North Star: "The Guided Path"**

Most accessibility-focused designs fall into the trap of "clinical utility"—they are functional but lack soul. This design system rejects the premise that WCAG AAA compliance must be boring. Our North Star, **The Guided Path**, focuses on a hyper-linear, high-end editorial experience. We treat the UI not as a complex dashboard, but as a prestigious, single-column stream of information. 

By leveraging intentional asymmetry and "Hyper-Contrast Minimalism," we create an environment where the interface recedes, and the content—emphasized by massive, authoritative typography—takes center stage. We move beyond standard grids to a layout that feels curated, premium, and inherently navigable.

---

## 2. Colors & Surface Philosophy

Our palette is anchored in absolute darkness to provide the ultimate canvas for light. We follow a strict high-contrast ratio (WCAG AAA) while maintaining a premium aesthetic.

### The "No-Line" Rule
Traditional borders create visual noise that can confuse users with low vision. **1px solid borders are strictly prohibited.** Boundaries must be defined solely through background color shifts. For example, a card in `surface_container_high` sits against a `surface` background to create a clear, soft-edged boundary without the "vibration" of a high-contrast line.

### Surface Hierarchy & Nesting
We use Material Design Tonal Layering to create depth without shadows:
- **Base Layer:** `surface` (#131313) - The primary canvas.
- **Sectioning:** `surface_container_low` (#1B1B1B) - Used for grouping content blocks.
- **Interactive Objects:** `surface_container_highest` (#353535) - For elements that require elevation or touch interaction.

### The "Glass & Soul" Rule
To prevent the app from feeling "flat," main interactive CTAs should utilize a subtle **Luminescent Gradient**. Instead of a flat #FFD600, use a linear gradient from `primary` (#FFF5DC) to `primary_container` (#FFD600) at a 45-degree angle. This provides a "glow" that aids in rapid visual identification.

---

## 3. Typography: The Lexend Scale

We utilize **Lexend**, a typeface specifically designed to reduce cognitive load and improve reading speed.

- **Display (Large/3.5rem):** Reserved for hero welcome states or primary navigational landmarks.
- **Headline (Medium/1.75rem):** Used for post headers and section titles. Headlines are the "Anchors" of the linear layout.
- **Body (Large/1rem):** This is our standard reading size. We never go below 16px (1rem) for body text to ensure maximum legibility.
- **Labels (Medium/0.75rem):** Used sparingly for metadata. All labels must use `on_surface_variant` (#D0C6AB) to maintain a clear hierarchy against primary white text.

**Editorial Intent:** Use `headline-lg` for the first word of a primary section to create a "drop-cap" feel, signaling a clear start to a new content block.

---

## 4. Elevation & Depth: Tonal Layering

We eschew traditional drop shadows for **Tonal Stacking**.

- **The Layering Principle:** To "lift" a component, move up the surface scale. A `surface_container_highest` (#353535) card on a `surface` (#131313) background provides sufficient contrast and perceived elevation for visually impaired users without the "muddy" look of standard shadows.
- **The Ghost Border:** For accessibility focus states, we do not use solid lines. Use the `outline_variant` (#4D4632) at 20% opacity as a soft outer glow, paired with a high-visibility `primary_container` (#FFD600) inner ring.
- **Glassmorphism:** Use `surface_bright` (#393939) at 80% opacity with a `20px backdrop-blur` for sticky navigation headers. This allows the high-contrast content to scroll underneath while maintaining the context of the current screen.

---

## 5. Components

### Buttons (The 48dp Minimum)
- **Primary:** Background: `primary_container` (#FFD600), Text: `on_primary` (#3A3000). Roundedness: `xl` (0.75rem).
- **Secondary:** Background: `surface_container_highest` (#353535), Text: `primary` (#FFF5DC).
- **States:** On Focus/Hover, the button must expand by 4px using a `primary_fixed` (#FFE170) outer glow.

### Cards & Lists (The Linear Stream)
- **Rules:** Forbid divider lines.
- **Implementation:** Separate list items using `1.5rem` (24px) of vertical white space. Each list item is a `surface_container_low` block.
- **Leading Elements:** Icons or avatars must be a minimum of 56px to serve as clear visual targets.

### Input Fields
- **Design:** Use "Underline Plus" styling. A thick 4px bottom bar in `outline` (#999077) that transforms into a `primary_container` (#FFD600) bar when active. 
- **Touch Target:** The entire field area must be at least 56dp in height.

### The "Aura" Focus State
Every interactive element, when focused via screen reader or keyboard, must exhibit an "Aura"—a 4px outer glow of `tertiary_container` (#00F0FC). This provides a secondary color-coded "Blue Alert" that is distinct from the brand's yellow accents.

---

## 6. Do's and Don'ts

### Do
- **Do** use `primary_container` (#FFD600) for all primary actions; it is the "North Star" of interaction.
- **Do** utilize the full width of the screen for text. A single-column linear layout is the most predictable path for low-vision navigation.
- **Do** ensure every icon is accompanied by a `label-md` text description. Icons should never stand alone.

### Don't
- **Don't** use 1px dividers. They are invisible to many and create visual "clutter."
- **Don't** use "Light Mode." This system is built for light sensitivity; pure black backgrounds reduce glare and eye strain.
- **Don't** use standard "Grey" for disabled states. Use `surface_container_highest` with 40% opacity on text to maintain a premium, editorial feel even in inactive states.
- **Don't** use "Center Aligned" text for long blocks. Keep all body and headline text Left Aligned (or Right Aligned for RTL) to provide a consistent "starting line" for the eye.

---

## 7. Signature Interaction: The Haptic Pulse
In this design system, every interaction with a `primary` element should be accompanied by a "Haptic Pulse" (medium-impact haptic feedback). This creates a multi-sensory confirmation of success, ensuring the app feels "physical" and responsive to the user’s touch.